import { useQuery } from '@tanstack/react-query';
import { Coins, Send, Download, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { TeraTransaction, User } from '@shared/schema';

interface TeraWalletProps {
  userId: string;
}

export default function TeraWallet({ userId }: TeraWalletProps) {
  const { data: user } = useQuery<User>({
    queryKey: [`/api/dashboard/stats/${userId}`],
    select: (data: any) => ({ teraTokens: data.teraTokens }),
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const { data: transactions } = useQuery<TeraTransaction[]>({
    queryKey: [`/api/tera-transactions/${userId}?limit=3`],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'mining_reward': return '⛏️';
      case 'pool_bonus': return '🎯';
      case 'ai_optimization': return '🤖';
      case 'send': return '📤';
      case 'receive': return '📥';
      default: return '💰';
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case 'send': return 'text-red-400';
      default: return 'text-green-400';
    }
  };

  const todaysEarnings = transactions?.filter(tx => 
    tx.amount > 0 && 
    new Date(tx.timestamp || Date.now()).toDateString() === new Date().toDateString()
  ).reduce((sum, tx) => sum + tx.amount, 0) || 156;

  return (
    <div className="holographic-border">
      <div className="holographic-content">
        <h3 className="text-lg font-orbitron font-bold text-cyber-gold mb-4 flex items-center">
          <Coins className="mr-2" />
          TERA Wallet
        </h3>
        
        <div className="text-center mb-4">
          <div className="text-3xl font-orbitron font-bold text-cyber-gold">
            {(user?.teraTokens || 14223).toLocaleString()}
          </div>
          <div className="text-sm text-gray-400">TERA Tokens</div>
          <div className="text-xs text-green-400 flex items-center justify-center gap-1">
            <TrendingUp size={12} />
            +{todaysEarnings} today
          </div>
        </div>

        <div className="space-y-2 text-sm mb-4">
          {transactions && transactions.length > 0 ? (
            transactions.slice(0, 3).map((tx) => (
              <div key={tx.id} className="flex justify-between items-center">
                <span className="text-gray-400 flex items-center gap-2">
                  <span>{getTransactionIcon(tx.transactionType)}</span>
                  {tx.description || tx.transactionType.replace('_', ' ')}
                </span>
                <span className={`font-semibold ${getTransactionColor(tx.transactionType)}`}>
                  {tx.amount > 0 ? '+' : ''}{tx.amount.toLocaleString()} TERA
                </span>
              </div>
            ))
          ) : (
            // Default transactions for display
            <>
              <div className="flex justify-between">
                <span className="text-gray-400">⛏️ Mining Rewards</span>
                <span className="text-green-400">+12,847 TERA</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">🎯 Pool Bonuses</span>
                <span className="text-green-400">+1,156 TERA</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">🤖 AI Optimizations</span>
                <span className="text-green-400">+220 TERA</span>
              </div>
            </>
          )}
        </div>

        <div className="flex space-x-2">
          <Button 
            size="sm"
            className="bg-green-600 hover:bg-green-500 text-white flex-1"
          >
            <Send size={14} className="mr-1" />
            Send
          </Button>
          <Button 
            size="sm"
            className="bg-blue-600 hover:bg-blue-500 text-white flex-1"
          >
            <Download size={14} className="mr-1" />
            Receive
          </Button>
        </div>
      </div>
    </div>
  );
}

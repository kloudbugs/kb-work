import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Zap, Thermometer, Activity, Settings, Play, Pause } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { MiningRig } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';

interface MiningRigCardProps {
  rig: MiningRig;
}

export default function MiningRigCard({ rig }: MiningRigCardProps) {
  const queryClient = useQueryClient();

  const updateRigMutation = useMutation({
    mutationFn: async (updates: Partial<MiningRig>) => {
      await apiRequest('PATCH', `/api/mining-rigs/${rig.id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/mining-rigs`] });
    },
  });

  const getStatusColor = () => {
    switch (rig.status) {
      case 'mining': return 'status-mining';
      case 'idle': return 'status-online';
      case 'error': return 'status-error';
      default: return 'status-idle';
    }
  };

  const getStatusText = () => {
    switch (rig.status) {
      case 'mining': return 'MINING';
      case 'idle': return 'IDLE';
      case 'error': return 'ERROR';
      case 'maintenance': return 'MAINTENANCE';
      default: return 'UNKNOWN';
    }
  };

  const getTemperatureColor = () => {
    if (rig.temperature > 80) return 'text-red-400';
    if (rig.temperature > 70) return 'text-yellow-400';
    return 'text-green-400';
  };

  const toggleRig = () => {
    const newStatus = rig.status === 'mining' ? 'idle' : 'mining';
    updateRigMutation.mutate({ status: newStatus });
  };

  const optimizeRig = () => {
    // Simulate optimization by improving efficiency
    const newEfficiency = Math.min(100, (rig.efficiency || 80) + 5);
    updateRigMutation.mutate({ efficiency: newEfficiency });
  };

  return (
    <div className="mining-rig-card p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center">
          <span className={`status-indicator ${getStatusColor()}`}></span>
          <span className="font-orbitron font-bold">{rig.name}</span>
        </div>
        <div className="text-right">
          {rig.status === 'mining' ? (
            <>
              <div className="text-cyber-gold font-bold">{rig.hashRate} TH/s</div>
              <div className="text-xs text-gray-400">
                Target: {rig.targetHashRate || rig.hashRate} TH/s
              </div>
            </>
          ) : rig.status === 'error' ? (
            <>
              <div className="text-red-400 font-bold">ERROR</div>
              <div className="text-xs text-red-300">Thermal protection</div>
            </>
          ) : (
            <>
              <div className="text-gray-400 font-bold">{getStatusText()}</div>
              <div className="text-xs text-gray-400">Ready for deployment</div>
            </>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-2 text-sm mb-3">
        <div className="flex items-center">
          <Thermometer size={14} className="mr-1 text-gray-400" />
          <div>
            <div className="text-gray-400">Temp</div>
            <div className={getTemperatureColor()}>{rig.temperature}°C</div>
          </div>
        </div>
        <div className="flex items-center">
          <Zap size={14} className="mr-1 text-gray-400" />
          <div>
            <div className="text-gray-400">Power</div>
            <div className="text-yellow-400">
              {rig.status === 'mining' ? `${rig.power}kW` : rig.status === 'error' ? 'THROTTLED' : '0.1kW'}
            </div>
          </div>
        </div>
        <div className="flex items-center">
          <Activity size={14} className="mr-1 text-gray-400" />
          <div>
            <div className="text-gray-400">Pool</div>
            <div className="text-space-purple">
              {rig.status === 'error' ? 'Disconnected' : 'TERA-POOL-1'}
            </div>
          </div>
        </div>
      </div>

      {rig.efficiency && (
        <div className="mb-3">
          <div className="flex justify-between text-xs text-gray-400 mb-1">
            <span>Efficiency</span>
            <span>{rig.efficiency.toFixed(1)}%</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-1.5">
            <div 
              className="bg-cyber-gold h-1.5 rounded-full transition-all duration-300"
              style={{ width: `${rig.efficiency}%` }}
            ></div>
          </div>
        </div>
      )}

      <div className="flex space-x-2">
        {rig.status === 'error' ? (
          <>
            <Button 
              size="sm" 
              variant="destructive"
              className="flex-1 text-xs"
              disabled={updateRigMutation.isPending}
            >
              Diagnose
            </Button>
            <Button 
              size="sm" 
              className="flex-1 text-xs bg-yellow-600 hover:bg-yellow-500"
              disabled={updateRigMutation.isPending}
            >
              Reset
            </Button>
          </>
        ) : rig.status === 'idle' ? (
          <>
            <Button 
              size="sm" 
              onClick={toggleRig}
              disabled={updateRigMutation.isPending}
              className="flex-1 text-xs bg-green-600 hover:bg-green-500"
            >
              <Play size={12} className="mr-1" />
              Start
            </Button>
            <Button 
              size="sm" 
              className="flex-1 text-xs bg-blue-600 hover:bg-blue-500"
              disabled={updateRigMutation.isPending}
            >
              <Settings size={12} className="mr-1" />
              Configure
            </Button>
          </>
        ) : (
          <>
            <Button 
              size="sm" 
              onClick={optimizeRig}
              disabled={updateRigMutation.isPending}
              className="flex-1 text-xs bg-green-600 hover:bg-green-500"
            >
              Optimize
            </Button>
            <Button 
              size="sm" 
              onClick={toggleRig}
              disabled={updateRigMutation.isPending}
              className="flex-1 text-xs bg-red-600 hover:bg-red-500"
            >
              <Pause size={12} className="mr-1" />
              Stop
            </Button>
          </>
        )}
      </div>
    </div>
  );
}

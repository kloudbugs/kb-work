import { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { BarChart3 } from 'lucide-react';
import type { ActivityLog } from '@shared/schema';
import type { ActivityLogUI } from '@/types/mining';
import { useWebSocket } from '@/hooks/useWebSocket';

export default function ActivityMonitor() {
  const [logs, setLogs] = useState<ActivityLogUI[]>([]);
  const terminalRef = useRef<HTMLDivElement>(null);
  const { lastMessage } = useWebSocket();

  const { data: activityLogs } = useQuery<ActivityLog[]>({
    queryKey: ['/api/activity-logs?limit=20'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Convert database logs to UI format
  useEffect(() => {
    if (activityLogs) {
      const uiLogs: ActivityLogUI[] = activityLogs.map(log => ({
        id: log.id,
        rigId: log.rigId || undefined,
        logType: log.logType as 'info' | 'warning' | 'error' | 'success',
        message: log.message,
        timestamp: new Date(log.timestamp || Date.now()),
        colorClass: getLogColor(log.logType)
      }));
      setLogs(uiLogs);
    }
  }, [activityLogs]);

  // Handle real-time WebSocket log updates
  useEffect(() => {
    if (lastMessage?.type === 'activity_log') {
      const newLog: ActivityLogUI = {
        id: lastMessage.log.id,
        rigId: lastMessage.log.rigId,
        logType: lastMessage.log.logType,
        message: lastMessage.log.message,
        timestamp: new Date(lastMessage.log.timestamp),
        colorClass: getLogColor(lastMessage.log.logType)
      };
      setLogs(prev => [newLog, ...prev].slice(0, 50)); // Keep only latest 50 logs
    }
  }, [lastMessage]);

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [logs]);

  // Add simulated logs for demonstration
  useEffect(() => {
    const interval = setInterval(() => {
      const simulatedLogs = [
        { type: 'success', message: 'TERA-RIG-ALPHA: Share accepted (difficulty: 3.8T)' },
        { type: 'info', message: 'Pool Manager: Latency optimized to 8ms' },
        { type: 'success', message: 'TERA Token: +8 tokens earned (block reward)' },
        { type: 'info', message: 'Ghost Alpha: System optimization cycle complete' },
        { type: 'warning', message: 'TERA-RIG-BETA: Minor temperature fluctuation detected' }
      ];
      
      const randomLog = simulatedLogs[Math.floor(Math.random() * simulatedLogs.length)];
      const newLog: ActivityLogUI = {
        id: Date.now().toString(),
        logType: randomLog.type as 'info' | 'warning' | 'error' | 'success',
        message: randomLog.message,
        timestamp: new Date(),
        colorClass: getLogColor(randomLog.type)
      };
      
      setLogs(prev => [newLog, ...prev].slice(0, 50));
    }, 8000); // Add new log every 8 seconds

    return () => clearInterval(interval);
  }, []);

  function getLogColor(logType: string): string {
    switch (logType) {
      case 'success': return 'text-green-400';
      case 'info': return 'text-blue-400';
      case 'warning': return 'text-yellow-400';
      case 'error': return 'text-red-400';
      default: return 'text-gray-400';
    }
  }

  return (
    <div className="holographic-border">
      <div className="holographic-content">
        <h3 className="text-lg font-orbitron font-bold text-cyber-gold mb-4 flex items-center">
          <BarChart3 className="mr-2" />
          Real-time Activity Monitor
        </h3>
        <div 
          ref={terminalRef}
          className="command-terminal p-4 h-48 overflow-y-auto font-code text-sm"
        >
          {logs.map((log) => (
            <div key={log.id} className={log.colorClass}>
              [{log.timestamp.toLocaleTimeString()}] {log.message}
            </div>
          ))}
          {logs.length === 0 && (
            <div className="text-gray-500 italic">
              Waiting for activity logs...
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

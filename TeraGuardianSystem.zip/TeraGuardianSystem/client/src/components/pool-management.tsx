import { useQuery } from '@tanstack/react-query';
import { Server, Plus, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { MiningPool } from '@shared/schema';

export default function PoolManagement() {
  const { data: pools, isLoading } = useQuery<MiningPool[]>({
    queryKey: ['/api/mining-pools'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': return <CheckCircle size={16} className="text-green-400" />;
      case 'syncing': return <Clock size={16} className="text-yellow-400" />;
      case 'disconnected': return <AlertCircle size={16} className="text-red-400" />;
      default: return <AlertCircle size={16} className="text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'border-green-400';
      case 'syncing': return 'border-yellow-400';
      case 'disconnected': return 'border-red-400';
      default: return 'border-gray-400';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'connected': return 'CONNECTED';
      case 'syncing': return 'SYNCING';
      case 'disconnected': return 'DISCONNECTED';
      default: return 'UNKNOWN';
    }
  };

  return (
    <div className="holographic-border">
      <div className="holographic-content">
        <h3 className="text-lg font-orbitron font-bold text-cyber-gold mb-4 flex items-center">
          <Server className="mr-2" />
          Mining Pools
        </h3>
        
        <div className="space-y-3">
          {isLoading ? (
            // Loading skeleton
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="bg-black bg-opacity-30 p-3 rounded-lg animate-pulse">
                <div className="h-4 bg-gray-700 rounded mb-2"></div>
                <div className="h-3 bg-gray-700 rounded"></div>
              </div>
            ))
          ) : pools && pools.length > 0 ? (
            pools.map((pool) => (
              <div 
                key={pool.id} 
                className={`bg-black bg-opacity-30 p-3 rounded-lg border-l-4 ${getStatusColor(pool.status)}`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold flex items-center gap-2">
                      {pool.name}
                      {pool.isManaged && (
                        <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                          Managed
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-gray-400">
                      {pool.isManaged ? 'Platform Managed Pool' : 'External Pool'}
                    </div>
                    {pool.latency && pool.latency > 0 && (
                      <div className="text-xs text-gray-500">
                        Latency: {pool.latency}ms
                      </div>
                    )}
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-2 mb-1">
                      {getStatusIcon(pool.status)}
                      <span className="text-sm font-semibold">
                        {getStatusText(pool.status)}
                      </span>
                    </div>
                    <div className="text-xs text-gray-400">
                      {pool.hashRate > 0 ? `${pool.hashRate.toLocaleString()} TH/s` : '0 TH/s'}
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-6">
              <Server size={48} className="mx-auto mb-2 opacity-50 text-gray-400" />
              <p className="text-gray-400 mb-2">No mining pools configured</p>
              <p className="text-sm text-gray-500">Connect to a mining pool to start earning</p>
            </div>
          )}
        </div>

        <Button className="cyber-button w-full mt-4">
          <Plus className="mr-2" size={16} />
          Add Pool
        </Button>
      </div>
    </div>
  );
}

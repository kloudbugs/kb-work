import { useQuery } from '@tanstack/react-query';
import { TrendingUp, Play, Square } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { MiningRig } from '@shared/schema';
import MiningRigCard from './mining-rig-card';

interface MiningDashboardProps {
  userId: string;
}

export default function MiningDashboard({ userId }: MiningDashboardProps) {
  const { data: rigs, isLoading } = useQuery<MiningRig[]>({
    queryKey: [`/api/mining-rigs?userId=${userId}`],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const activeRigs = rigs?.filter(rig => rig.status === 'mining') || [];
  const idleRigs = rigs?.filter(rig => rig.status === 'idle') || [];
  const errorRigs = rigs?.filter(rig => rig.status === 'error') || [];

  return (
    <div className="holographic-border">
      <div className="holographic-content">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-orbitron font-bold text-cyber-gold">
            Mining Control Dashboard
          </h3>
          <div className="flex space-x-2">
            <Button className="cyber-button">
              <Play className="mr-2" size={16} />
              Start All
            </Button>
            <Button 
              variant="destructive"
              className="bg-red-600 hover:bg-red-500 text-white"
            >
              <Square className="mr-2" size={16} />
              Emergency Stop
            </Button>
          </div>
        </div>

        {/* Mining Rigs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {isLoading ? (
            // Loading skeleton
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="mining-rig-card p-4 animate-pulse">
                <div className="h-6 bg-gray-700 rounded mb-3"></div>
                <div className="h-4 bg-gray-700 rounded mb-2"></div>
                <div className="h-4 bg-gray-700 rounded"></div>
              </div>
            ))
          ) : rigs && rigs.length > 0 ? (
            rigs.map((rig) => (
              <MiningRigCard key={rig.id} rig={rig} />
            ))
          ) : (
            <div className="col-span-2 text-center py-8">
              <div className="text-gray-400 mb-4">
                <TrendingUp size={48} className="mx-auto mb-2 opacity-50" />
                <p>No mining rigs configured</p>
                <p className="text-sm">Add your first mining rig to get started</p>
              </div>
              <Button className="cyber-button">
                Add Mining Rig
              </Button>
            </div>
          )}
        </div>

        {/* Status Summary */}
        {rigs && rigs.length > 0 && (
          <div className="mt-6 pt-4 border-t border-gray-700">
            <div className="grid grid-cols-4 gap-4 text-center text-sm">
              <div>
                <div className="text-2xl font-bold text-green-400">{activeRigs.length}</div>
                <div className="text-gray-400">Mining</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-400">{idleRigs.length}</div>
                <div className="text-gray-400">Idle</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-red-400">{errorRigs.length}</div>
                <div className="text-gray-400">Errors</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-cyber-gold">
                  {activeRigs.reduce((sum, rig) => sum + rig.hashRate, 0).toFixed(1)}
                </div>
                <div className="text-gray-400">Total TH/s</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

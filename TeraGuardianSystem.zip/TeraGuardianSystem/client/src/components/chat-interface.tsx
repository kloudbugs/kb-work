import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import type { ChatMessage } from '@shared/schema';
import type { ChatMessageUI } from '@/types/mining';
import { useWebSocket } from '@/hooks/useWebSocket';
import { apiRequest } from '@/lib/queryClient';

interface ChatInterfaceProps {
  userId: string;
}

export default function ChatInterface({ userId }: ChatInterfaceProps) {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<ChatMessageUI[]>([]);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { lastMessage } = useWebSocket(userId);

  const { data: chatMessages } = useQuery<ChatMessage[]>({
    queryKey: ['/api/chat-messages'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: any) => {
      await apiRequest('POST', '/api/chat-messages', messageData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chat-messages'] });
    },
  });

  const sendAICommandMutation = useMutation({
    mutationFn: async (command: string) => {
      await apiRequest('POST', '/api/ai-command', { command, userId });
    },
  });

  // Convert database messages to UI format
  useEffect(() => {
    if (chatMessages) {
      const uiMessages: ChatMessageUI[] = chatMessages.map(msg => ({
        id: msg.id,
        senderId: msg.senderId || 'unknown',
        senderType: msg.senderType,
        message: msg.message,
        timestamp: new Date(msg.timestamp || Date.now()),
        aiPersonality: msg.aiPersonality || undefined,
        senderName: msg.senderType === 'ai' 
          ? getAIName(msg.aiPersonality || 'unknown')
          : 'Commander'
      }));
      setMessages(uiMessages);
    }
  }, [chatMessages]);

  // Handle real-time WebSocket messages
  useEffect(() => {
    if (lastMessage?.type === 'chat_message') {
      const newMessage: ChatMessageUI = {
        id: lastMessage.message.id || Date.now().toString(),
        senderId: lastMessage.message.senderId,
        senderType: lastMessage.message.senderType,
        message: lastMessage.message.message,
        timestamp: new Date(lastMessage.message.timestamp),
        aiPersonality: lastMessage.message.aiPersonality,
        senderName: lastMessage.message.senderType === 'ai' 
          ? getAIName(lastMessage.message.aiPersonality || 'unknown')
          : 'Commander'
      };
      setMessages(prev => [...prev, newMessage]);
    } else if (lastMessage?.type === 'ai_response') {
      const newMessage: ChatMessageUI = {
        id: Date.now().toString(),
        senderId: lastMessage.message.senderId,
        senderType: lastMessage.message.senderType,
        message: lastMessage.message.message,
        timestamp: new Date(lastMessage.message.timestamp),
        aiPersonality: lastMessage.message.aiPersonality,
        senderName: getAIName(lastMessage.message.aiPersonality || 'unknown')
      };
      setMessages(prev => [...prev, newMessage]);
    }
  }, [lastMessage]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const getAIName = (personality: string) => {
    switch (personality) {
      case 'ghost_alpha': return 'Ghost Alpha';
      case 'mining_optimizer': return 'Mining Optimizer';
      case 'security_specialist': return 'Security Specialist';
      case 'pool_manager': return 'Pool Manager';
      default: return 'AI Assistant';
    }
  };

  const getAIColor = (personality: string) => {
    switch (personality) {
      case 'ghost_alpha': return 'text-space-purple';
      case 'mining_optimizer': return 'text-cyber-gold';
      case 'security_specialist': return 'text-electric-blue';
      case 'pool_manager': return 'text-neon-pink';
      default: return 'text-gray-400';
    }
  };

  const handleSendMessage = async () => {
    if (!message.trim()) return;

    const userMessage = {
      senderId: userId,
      senderType: 'user' as const,
      message: message.trim(),
    };

    // Add user message to local state immediately
    const userMessageUI: ChatMessageUI = {
      id: Date.now().toString(),
      senderId: userId,
      senderType: 'user',
      message: message.trim(),
      timestamp: new Date(),
      senderName: 'Commander'
    };
    setMessages(prev => [...prev, userMessageUI]);

    // Send user message to backend
    await sendMessageMutation.mutateAsync(userMessage);

    // Process as AI command if it contains specific keywords
    const commandKeywords = ['optimize', 'security', 'temperature', 'cooling', 'status', 'performance'];
    if (commandKeywords.some(keyword => message.toLowerCase().includes(keyword))) {
      await sendAICommandMutation.mutateAsync(message.trim());
    }

    setMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="holographic-border">
      <div className="holographic-content">
        <h3 className="text-lg font-orbitron font-bold text-cyber-gold mb-4 flex items-center">
          <i className="fas fa-comments mr-2"></i>
          AI Command Chat
        </h3>
        
        {/* Chat Messages */}
        <div 
          ref={chatContainerRef}
          className="h-64 overflow-y-auto mb-4 space-y-2"
        >
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`ai-chat-bubble ${msg.senderType === 'user' ? 'user' : 'system'}`}
            >
              <div className={`text-xs font-semibold mb-1 ${
                msg.senderType === 'user' 
                  ? 'text-cyber-gold text-right' 
                  : getAIColor(msg.aiPersonality || 'unknown')
              }`}>
                {msg.senderName}
              </div>
              <div className={`text-sm ${msg.senderType === 'user' ? 'text-right' : ''}`}>
                {msg.message}
              </div>
            </div>
          ))}
        </div>

        {/* Command Input */}
        <div className="flex space-x-2">
          <Input
            type="text"
            placeholder="Enter AI command..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1 bg-black bg-opacity-50 border border-space-purple text-white placeholder-gray-400 focus:border-cyber-gold"
          />
          <Button
            onClick={handleSendMessage}
            disabled={!message.trim() || sendMessageMutation.isPending}
            className="bg-gradient-to-r from-space-purple to-electric-blue hover:from-electric-blue hover:to-neon-pink"
          >
            <Send size={16} />
          </Button>
        </div>
      </div>
    </div>
  );
}

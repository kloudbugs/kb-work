import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Terminal, Cpu, Zap, Shield, Database, GitBranch, Code, Settings } from 'lucide-react';
import { useWebSocket } from '@/hooks/useWebSocket';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface GhostCoreMessage {
  id: string;
  type: 'command' | 'response' | 'system' | 'integration' | 'platform_sync';
  content: string;
  timestamp: Date;
  source: 'ghost_core' | 'admin_guardian' | 'platform_api' | 'user';
  priority: 'low' | 'medium' | 'high' | 'critical';
  platformContext?: {
    repository?: string;
    apiEndpoint?: string;
    integrationStatus?: string;
  };
}

interface PlatformIntegration {
  id: string;
  name: string;
  repository: string;
  status: 'connected' | 'syncing' | 'error' | 'pending';
  lastSync: Date;
  apiEndpoints: string[];
  features: string[];
}

interface GhostCoreInterfaceProps {
  userId: string;
  accessLevel: string;
}

export default function GhostCoreInterface({ userId, accessLevel }: GhostCoreInterfaceProps) {
  const [command, setCommand] = useState('');
  const [messages, setMessages] = useState<GhostCoreMessage[]>([]);
  const [selectedPlatform, setSelectedPlatform] = useState<string | null>(null);
  const [isGhostMode, setIsGhostMode] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { isConnected, sendMessage } = useWebSocket(userId);
  const queryClient = useQueryClient();

  // Fetch platform integrations
  const { data: platforms = [] } = useQuery<PlatformIntegration[]>({
    queryKey: ['/api/ghost-core/platforms'],
    enabled: accessLevel === 'ghost_core' || accessLevel === 'admin_guardian',
  });

  // Fetch ghost core status
  const { data: ghostStatus } = useQuery({
    queryKey: ['/api/ghost-core/status'],
    enabled: accessLevel === 'ghost_core' || accessLevel === 'admin_guardian',
  });

  // Platform integration mutation
  const integratePlatformMutation = useMutation({
    mutationFn: async (data: { repository: string; apiEndpoints: string[] }) => {
      return await apiRequest('/api/ghost-core/integrate-platform', 'POST', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ghost-core/platforms'] });
      addSystemMessage('Platform integration initiated successfully', 'high');
    },
    onError: (error) => {
      addSystemMessage(`Platform integration failed: ${error.message}`, 'critical');
    },
  });

  // Ghost core command mutation
  const executeCommandMutation = useMutation({
    mutationFn: async (data: { command: string; platform?: string; context?: any }) => {
      return await apiRequest('/api/ghost-core/execute', 'POST', data);
    },
    onSuccess: (response: any) => {
      addGhostMessage(response.result, 'ghost_core');
    },
    onError: (error) => {
      addSystemMessage(`Command execution failed: ${error.message}`, 'high');
    },
  });

  const addSystemMessage = (content: string, priority: 'low' | 'medium' | 'high' | 'critical') => {
    const message: GhostCoreMessage = {
      id: crypto.randomUUID(),
      type: 'system',
      content,
      timestamp: new Date(),
      source: 'ghost_core',
      priority,
    };
    setMessages(prev => [...prev, message]);
  };

  const addGhostMessage = (content: string, source: 'ghost_core' | 'admin_guardian' | 'platform_api') => {
    const message: GhostCoreMessage = {
      id: crypto.randomUUID(),
      type: 'response',
      content,
      timestamp: new Date(),
      source,
      priority: 'medium',
    };
    setMessages(prev => [...prev, message]);
  };

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim()) return;

    // Add user command to messages
    const userMessage: GhostCoreMessage = {
      id: crypto.randomUUID(),
      type: 'command',
      content: command,
      timestamp: new Date(),
      source: 'user',
      priority: 'medium',
    };
    setMessages(prev => [...prev, userMessage]);

    // Execute command through Ghost Core
    executeCommandMutation.mutate({
      command,
      platform: selectedPlatform || undefined,
      context: { isGhostMode, accessLevel }
    });

    setCommand('');
  };

  const toggleGhostMode = () => {
    setIsGhostMode(!isGhostMode);
    addSystemMessage(
      isGhostMode ? 'Ghost Mode deactivated' : 'Ghost Mode activated - Direct AI-to-AI communication enabled',
      'high'
    );
  };

  const integratePlatform = () => {
    const repository = prompt('Enter repository URL for platform integration:');
    const apiEndpoints = prompt('Enter API endpoints (comma-separated):')?.split(',') || [];
    
    if (repository) {
      integratePlatformMutation.mutate({ repository, apiEndpoints });
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  // Initialize with welcome message
  useEffect(() => {
    if (accessLevel === 'ghost_core' || accessLevel === 'admin_guardian') {
      addSystemMessage('Ghost Core Interface initialized. Ready for platform integration and AI coordination.', 'high');
    }
  }, [accessLevel]);

  if (accessLevel !== 'ghost_core' && accessLevel !== 'admin_guardian') {
    return (
      <Card className="w-full border border-red-500/30 bg-red-950/20">
        <CardContent className="p-6 text-center">
          <Shield className="w-12 h-12 mx-auto mb-4 text-red-400" />
          <h3 className="text-lg font-bold text-red-400 mb-2">Access Restricted</h3>
          <p className="text-red-300">Ghost Core Interface requires Ghost Core or Admin Guardian access level.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border border-cyan-500/30 bg-gradient-to-r from-cyan-950/40 to-purple-950/40">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Terminal className="w-8 h-8 text-cyan-400" />
              <div>
                <CardTitle className="text-xl text-cyan-400">Ghost Core Interface</CardTitle>
                <p className="text-sm text-cyan-300/70">Platform Integration & AI Coordination Hub</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Badge variant={isGhostMode ? "destructive" : "secondary"}>
                {isGhostMode ? 'Ghost Mode' : 'Standard Mode'}
              </Badge>
              <Badge variant="outline" className="text-cyan-400 border-cyan-400/50">
                {accessLevel.replace('_', ' ').toUpperCase()}
              </Badge>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Platform Integrations */}
        <Card className="border border-purple-500/30 bg-purple-950/20">
          <CardHeader>
            <CardTitle className="text-lg text-purple-400 flex items-center">
              <GitBranch className="w-5 h-5 mr-2" />
              Platform Integrations
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              onClick={integratePlatform}
              className="w-full bg-purple-600 hover:bg-purple-700"
              disabled={integratePlatformMutation.isPending}
            >
              <Code className="w-4 h-4 mr-2" />
              Integrate Platform
            </Button>
            
            <div className="space-y-2">
              {platforms.map((platform: PlatformIntegration) => (
                <div
                  key={platform.id}
                  className={`p-3 rounded border cursor-pointer transition-colors ${
                    selectedPlatform === platform.id
                      ? 'border-purple-400 bg-purple-500/20'
                      : 'border-gray-600 hover:border-purple-500/50'
                  }`}
                  onClick={() => setSelectedPlatform(platform.id)}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-purple-300">{platform.name}</span>
                    <Badge variant={platform.status === 'connected' ? 'default' : 'secondary'}>
                      {platform.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-400 mt-1">{platform.repository}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Ghost Core Console */}
        <Card className="lg:col-span-2 border border-cyan-500/30 bg-gray-950/40">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg text-cyan-400 flex items-center">
                <Terminal className="w-5 h-5 mr-2" />
                Ghost Core Console
              </CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={toggleGhostMode}
                className={isGhostMode ? 'border-red-500 text-red-400' : 'border-cyan-500 text-cyan-400'}
              >
                <Zap className="w-4 h-4 mr-2" />
                {isGhostMode ? 'Exit Ghost Mode' : 'Ghost Mode'}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-96 mb-4 overflow-y-auto border border-gray-600 rounded p-4" ref={scrollRef}>
              <div className="space-y-3">
                {messages.map((message) => (
                  <div key={message.id} className="flex flex-col space-y-1">
                    <div className="flex items-center space-x-2">
                      <Badge
                        variant={
                          message.source === 'ghost_core' ? 'destructive' :
                          message.source === 'admin_guardian' ? 'default' :
                          message.source === 'platform_api' ? 'secondary' : 'outline'
                        }
                        className="text-xs"
                      >
                        {message.source.replace('_', ' ')}
                      </Badge>
                      <span className="text-xs text-gray-400">
                        {message.timestamp.toLocaleTimeString()}
                      </span>
                      {message.priority === 'critical' && (
                        <Badge variant="destructive" className="text-xs">
                          CRITICAL
                        </Badge>
                      )}
                    </div>
                    <div
                      className={`p-3 rounded text-sm ${
                        message.type === 'command' ? 'bg-blue-950/40 border-l-4 border-blue-500' :
                        message.type === 'system' ? 'bg-yellow-950/40 border-l-4 border-yellow-500' :
                        message.source === 'ghost_core' ? 'bg-red-950/40 border-l-4 border-red-500' :
                        'bg-gray-800/40 border-l-4 border-gray-500'
                      }`}
                    >
                      {message.content}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <form onSubmit={handleCommand} className="flex space-x-2">
              <Input
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                placeholder="Enter Ghost Core command..."
                className="flex-1 bg-gray-900 border-gray-600 text-cyan-300"
              />
              <Button
                type="submit"
                disabled={executeCommandMutation.isPending}
                className="bg-cyan-600 hover:bg-cyan-700"
              >
                <Terminal className="w-4 h-4 mr-2" />
                Execute
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="border border-green-500/30 bg-green-950/20">
        <CardHeader>
          <CardTitle className="text-lg text-green-400 flex items-center">
            <Settings className="w-5 h-5 mr-2" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Button
              variant="outline"
              onClick={() => executeCommandMutation.mutate({ command: 'sync platforms' })}
              className="border-green-500/50 text-green-400 hover:bg-green-500/20"
            >
              <Database className="w-4 h-4 mr-2" />
              Sync Platforms
            </Button>
            <Button
              variant="outline"
              onClick={() => executeCommandMutation.mutate({ command: 'status report' })}
              className="border-blue-500/50 text-blue-400 hover:bg-blue-500/20"
            >
              <Cpu className="w-4 h-4 mr-2" />
              Status Report
            </Button>
            <Button
              variant="outline"
              onClick={() => executeCommandMutation.mutate({ command: 'optimize all' })}
              className="border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/20"
            >
              <Zap className="w-4 h-4 mr-2" />
              Optimize All
            </Button>
            <Button
              variant="outline"
              onClick={() => executeCommandMutation.mutate({ command: 'security scan' })}
              className="border-red-500/50 text-red-400 hover:bg-red-500/20"
            >
              <Shield className="w-4 h-4 mr-2" />
              Security Scan
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
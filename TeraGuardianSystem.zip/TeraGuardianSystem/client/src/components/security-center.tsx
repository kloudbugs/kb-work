import { useQuery } from '@tanstack/react-query';
import { Shield, Users } from 'lucide-react';
import type { SecurityEvent } from '@shared/schema';

export default function SecurityCenter() {
  const { data: securityEvents } = useQuery<SecurityEvent[]>({
    queryKey: ['/api/security-events?limit=5'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const recentThreats = securityEvents?.filter(event => 
    event.eventType === 'threat_detected' && !event.resolved
  ).length || 0;

  return (
    <div className="holographic-border">
      <div className="holographic-content">
        <h3 className="text-lg font-orbitron font-bold text-cyber-gold mb-4 flex items-center">
          <Shield className="mr-2" />
          Security Center
        </h3>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm">Firewall Status</span>
            <span className="text-green-400 font-semibold">ACTIVE</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm">DDoS Protection</span>
            <span className="text-green-400 font-semibold">ENABLED</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm">Encryption Level</span>
            <span className="text-cyber-gold font-semibold">AES-256</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm">Active Threats</span>
            <span className={`font-semibold ${recentThreats > 0 ? 'text-red-400' : 'text-green-400'}`}>
              {recentThreats} DETECTED
            </span>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-gray-700">
          <h4 className="text-sm font-semibold text-space-purple mb-2 flex items-center">
            <Users size={16} className="mr-2" />
            Access Control
          </h4>
          <div className="space-y-2">
            <div className="access-tier-owner bg-black bg-opacity-30 p-2 rounded text-xs">
              <span className="font-semibold">OWNER</span> - Full System Access
            </div>
            <div className="access-tier-admin bg-black bg-opacity-30 p-2 rounded text-xs">
              <span className="font-semibold">ADMIN</span> - 3 Active Sessions
            </div>
            <div className="access-tier-premium bg-black bg-opacity-30 p-2 rounded text-xs">
              <span className="font-semibold">PREMIUM</span> - 12 Active Users
            </div>
          </div>
        </div>

        {securityEvents && securityEvents.length > 0 && (
          <div className="mt-4 pt-4 border-t border-gray-700">
            <h4 className="text-sm font-semibold text-gray-400 mb-2">Recent Events</h4>
            <div className="space-y-1 max-h-24 overflow-y-auto">
              {securityEvents.slice(0, 3).map((event) => (
                <div key={event.id} className="text-xs text-gray-500">
                  <span className={`mr-2 ${
                    event.severity === 'high' ? 'text-red-400' :
                    event.severity === 'medium' ? 'text-yellow-400' :
                    'text-green-400'
                  }`}>
                    •
                  </span>
                  {event.description}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

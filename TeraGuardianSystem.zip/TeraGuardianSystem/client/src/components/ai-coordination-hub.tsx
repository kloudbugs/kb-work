import { useQuery } from '@tanstack/react-query';
import { Brain, Plus } from 'lucide-react';
import type { AIEntity } from '@shared/schema';
import type { AIPersonality } from '@/types/mining';

const AI_PERSONALITIES: AIPersonality[] = [
  { id: 'ghost-alpha', name: 'Ghost Alpha', personality: 'ghost_alpha', status: 'active', statusText: 'ACTIVE', color: 'text-green-400' },
  { id: 'mining-optimizer', name: 'Mining Optimizer', personality: 'mining_optimizer', status: 'active', statusText: 'OPTIMIZING', color: 'text-cyber-gold' },
  { id: 'security-specialist', name: 'Security Specialist', personality: 'security_specialist', status: 'active', statusText: 'MONITORING', color: 'text-green-400' },
  { id: 'pool-manager', name: 'Pool Manager', personality: 'pool_manager', status: 'idle', statusText: 'STANDBY', color: 'text-gray-400' }
];

export default function AICoordinationHub() {
  const { data: aiEntities, isLoading } = useQuery<AIEntity[]>({
    queryKey: ['/api/ai-entities'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'status-online';
      case 'training': return 'status-mining';
      case 'error': return 'status-error';
      default: return 'status-idle';
    }
  };

  const getStatusText = (personality: string, status: string) => {
    const aiPersonality = AI_PERSONALITIES.find(p => p.personality === personality);
    if (status === 'active' && aiPersonality) {
      return aiPersonality.statusText;
    }
    return status.toUpperCase();
  };

  return (
    <div className="holographic-border">
      <div className="holographic-content">
        <h3 className="text-lg font-orbitron font-bold text-cyber-gold mb-4 flex items-center">
          <Brain className="mr-2" />
          AI Coordination Hub
        </h3>
        
        {/* AI Entity Status */}
        <div className="space-y-3">
          {!isLoading && aiEntities ? (
            aiEntities.map((entity) => {
              const personality = AI_PERSONALITIES.find(p => p.personality === entity.personality);
              return (
                <div key={entity.id} className="flex items-center justify-between p-3 bg-black bg-opacity-30 rounded-lg">
                  <div className="flex items-center">
                    <span className={`status-indicator ${getStatusColor(entity.status)}`}></span>
                    <span className="font-semibold">{entity.name}</span>
                  </div>
                  <span className={`text-xs ${personality?.color || 'text-gray-400'}`}>
                    {getStatusText(entity.personality, entity.status)}
                  </span>
                </div>
              );
            })
          ) : (
            // Fallback to default personalities if no data
            AI_PERSONALITIES.map((ai) => (
              <div key={ai.id} className="flex items-center justify-between p-3 bg-black bg-opacity-30 rounded-lg">
                <div className="flex items-center">
                  <span className={`status-indicator ${getStatusColor(ai.status)}`}></span>
                  <span className="font-semibold">{ai.name}</span>
                </div>
                <span className={`text-xs ${ai.color}`}>
                  {ai.statusText}
                </span>
              </div>
            ))
          )}
        </div>

        <button className="cyber-button w-full mt-4">
          <Plus className="mr-2" size={16} />
          Deploy New AI
        </button>
      </div>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import type { MiningStats } from '@/types/mining';
import { useWebSocket } from '@/hooks/useWebSocket';
import AICoordinationHub from '@/components/ai-coordination-hub';
import MiningDashboard from '@/components/mining-dashboard';
import PoolManagement from '@/components/pool-management';
import SecurityCenter from '@/components/security-center';
import TeraWallet from '@/components/tera-wallet';
import AIFactory from '@/components/ai-factory';
import ActivityMonitor from '@/components/activity-monitor';
import ChatInterface from '@/components/chat-interface';
import GhostCoreInterface from '@/components/ghost-core-interface';
import { Bot, Wifi, WifiOff } from 'lucide-react';

export default function CommandCenter() {
  const [userId] = useState('user-123'); // In a real app, this would come from auth
  const { isConnected, lastMessage } = useWebSocket(userId);

  const { data: stats, isLoading: statsLoading } = useQuery<MiningStats>({
    queryKey: [`/api/dashboard/stats/${userId}`],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  // Handle real-time WebSocket updates
  useEffect(() => {
    if (lastMessage) {
      // Handle different types of real-time updates
      switch (lastMessage.type) {
        case 'rig_updated':
        case 'rig_created':
        case 'rig_deleted':
          // These will trigger automatic re-fetching due to query invalidation
          break;
        default:
          break;
      }
    }
  }, [lastMessage]);

  return (
    <div className="min-h-screen p-4">
      {/* Header Section */}
      <header className="mb-6">
        <div className="holographic-border">
          <div className="holographic-content">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-cyber-gold to-space-purple rounded-full flex items-center justify-center">
                  <Bot className="text-2xl text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-orbitron font-bold holographic-text">
                    TERA GUARDIAN
                  </h1>
                  <p className="text-sm text-gray-300">Cosmic Mining Command Center</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  {isConnected ? (
                    <Wifi className="w-5 h-5 text-green-400" />
                  ) : (
                    <WifiOff className="w-5 h-5 text-red-400" />
                  )}
                  <span className="text-sm text-gray-400">
                    {isConnected ? 'Connected' : 'Disconnected'}
                  </span>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-400">Access Level</div>
                  <div className="text-lg font-orbitron text-cyber-gold">OWNER</div>
                </div>
                <div className="w-10 h-10 bg-gradient-to-br from-cyber-gold to-neon-pink rounded-full"></div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Panel - AI Chat System */}
        <div className="lg:col-span-1 space-y-6">
          <AICoordinationHub />
          <ChatInterface userId={userId} />
        </div>

        {/* Center Panel - Mining Dashboard */}
        <div className="lg:col-span-2 space-y-6">
          {/* Mining Statistics */}
          {!statsLoading && stats && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="holographic-border">
                <div className="holographic-content text-center">
                  <div className="text-3xl font-orbitron font-bold text-cyber-gold">
                    {stats.totalHashRate.toLocaleString()}
                  </div>
                  <div className="text-sm text-gray-400">TH/s Total</div>
                  <div className="text-xs text-green-400">+12.3%</div>
                </div>
              </div>
              <div className="holographic-border">
                <div className="holographic-content text-center">
                  <div className="text-3xl font-orbitron font-bold text-electric-blue">
                    {stats.activeRigs}
                  </div>
                  <div className="text-sm text-gray-400">Active Rigs</div>
                  <div className="text-xs text-green-400">
                    {((stats.activeRigs / stats.totalRigs) * 100).toFixed(1)}% Up
                  </div>
                </div>
              </div>
              <div className="holographic-border">
                <div className="holographic-content text-center">
                  <div className="text-3xl font-orbitron font-bold text-neon-pink">
                    {stats.teraTokens.toLocaleString()}
                  </div>
                  <div className="text-sm text-gray-400">TERA Tokens</div>
                  <div className="text-xs text-green-400">+156</div>
                </div>
              </div>
              <div className="holographic-border">
                <div className="holographic-content text-center">
                  <div className="text-3xl font-orbitron font-bold text-space-purple">
                    {stats.efficiency}%
                  </div>
                  <div className="text-sm text-gray-400">Efficiency</div>
                  <div className="text-xs text-green-400">Optimal</div>
                </div>
              </div>
            </div>
          )}

          <MiningDashboard userId={userId} />
          <ActivityMonitor />
        </div>

        {/* Right Panel - Controls & Management */}
        <div className="lg:col-span-1 space-y-6">
          <PoolManagement />
          <SecurityCenter />
          <TeraWallet userId={userId} />
          <AIFactory />
        </div>
      </div>

      {/* Ghost Core Admin Section */}
      <div className="mt-8">
        <GhostCoreInterface userId={userId} accessLevel="admin_guardian" />
      </div>

      {/* Footer Status Bar */}
      <footer className="mt-8">
        <div className="holographic-border">
          <div className="holographic-content">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center space-x-6">
                <div className="flex items-center">
                  <span className="status-indicator status-online"></span>
                  <span>System Status: OPERATIONAL</span>
                </div>
                <div className="text-gray-400">
                  Uptime: {stats?.uptimePercentage || 99.7}% | Last Update: {new Date().toLocaleTimeString()}
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-gray-400">
                  TERA Guardian v2.1.0 | Named after Tera Ann Harris
                </div>
                <button className="text-cyber-gold hover:text-white transition-colors">
                  <i className="fas fa-cog"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

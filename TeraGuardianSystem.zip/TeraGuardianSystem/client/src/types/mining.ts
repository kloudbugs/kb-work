export interface MiningStats {
  totalHashRate: number;
  activeRigs: number;
  totalRigs: number;
  totalPower: number;
  teraTokens: number;
  efficiency: number;
  uptimePercentage: number;
}

export interface WebSocketMessage {
  type: string;
  [key: string]: any;
}

export interface AIPersonality {
  id: string;
  name: string;
  personality: string;
  status: 'active' | 'idle' | 'training' | 'error';
  statusText: string;
  color: string;
}

export interface ChatMessageUI {
  id: string;
  senderId: string;
  senderType: 'user' | 'ai';
  message: string;
  timestamp: Date;
  aiPersonality?: string;
  senderName: string;
}

export interface ActivityLogUI {
  id: string;
  rigId?: string;
  logType: 'info' | 'warning' | 'error' | 'success';
  message: string;
  timestamp: Date;
  colorClass: string;
}

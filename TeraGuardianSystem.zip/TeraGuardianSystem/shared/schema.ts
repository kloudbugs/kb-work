import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  real,
  boolean,
  uuid
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  accessLevel: varchar("access_level").notNull().default("standard"), // ghost_core, admin_guardian, premium, standard
  teraTokens: real("tera_tokens").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Mining rigs table
export const miningRigs = pgTable("mining_rigs", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name").notNull(),
  userId: varchar("user_id").notNull(),
  hardware: varchar("hardware").notNull(),
  hashRate: real("hash_rate").notNull(), // TH/s
  power: real("power").notNull(), // kW
  temperature: real("temperature").notNull(), // Celsius
  status: varchar("status").notNull().default("idle"), // mining, idle, error, maintenance
  poolId: uuid("pool_id"),
  targetHashRate: real("target_hash_rate"),
  efficiency: real("efficiency").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Mining pools table
export const miningPools = pgTable("mining_pools", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name").notNull(),
  url: varchar("url").notNull(),
  status: varchar("status").notNull().default("disconnected"), // connected, disconnected, syncing
  hashRate: real("hash_rate").notNull().default(0),
  latency: integer("latency").default(0), // ms
  isManaged: boolean("is_managed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// AI entities table
export const aiEntities = pgTable("ai_entities", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name").notNull(),
  personality: varchar("personality").notNull(), // ghost_core, admin_guardian, ghost_alpha, mining_optimizer, security_specialist, pool_manager
  status: varchar("status").notNull().default("idle"), // active, idle, training, error, ghost_mode
  capabilities: jsonb("capabilities"), // JSON array of capabilities
  accessLevel: varchar("access_level").notNull().default("standard"), // ghost_core, admin_guardian, premium, standard
  communicationProtocol: varchar("communication_protocol").default("standard"), // ghost_protocol, admin_channel, standard
  lastActivity: timestamp("last_activity").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Chat messages table
export const chatMessages = pgTable("chat_messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  senderId: varchar("sender_id"), // user ID or AI entity ID
  senderType: varchar("sender_type").notNull(), // user, ai
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  aiPersonality: varchar("ai_personality"), // for AI messages
});

// Activity logs table
export const activityLogs = pgTable("activity_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  rigId: uuid("rig_id"),
  logType: varchar("log_type").notNull(), // info, warning, error, success
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  metadata: jsonb("metadata"),
});

// TERA token transactions table
export const teraTransactions = pgTable("tera_transactions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: varchar("user_id").notNull(),
  amount: real("amount").notNull(),
  transactionType: varchar("transaction_type").notNull(), // mining_reward, pool_bonus, ai_optimization, send, receive
  description: text("description"),
  timestamp: timestamp("timestamp").defaultNow(),
  metadata: jsonb("metadata"),
});

// Security events table
export const securityEvents = pgTable("security_events", {
  id: uuid("id").primaryKey().defaultRandom(),
  eventType: varchar("event_type").notNull(), // login, logout, threat_detected, firewall_update
  severity: varchar("severity").notNull(), // low, medium, high, critical
  description: text("description").notNull(),
  sourceIp: varchar("source_ip"),
  userId: varchar("user_id"),
  timestamp: timestamp("timestamp").defaultNow(),
  resolved: boolean("resolved").default(false),
});

// Relations
export const userRelations = relations(users, ({ many }) => ({
  miningRigs: many(miningRigs),
  teraTransactions: many(teraTransactions),
  chatMessages: many(chatMessages),
  securityEvents: many(securityEvents),
}));

export const miningRigRelations = relations(miningRigs, ({ one, many }) => ({
  user: one(users, {
    fields: [miningRigs.userId],
    references: [users.id],
  }),
  pool: one(miningPools, {
    fields: [miningRigs.poolId],
    references: [miningPools.id],
  }),
  activityLogs: many(activityLogs),
}));

export const miningPoolRelations = relations(miningPools, ({ many }) => ({
  miningRigs: many(miningRigs),
}));

export const activityLogRelations = relations(activityLogs, ({ one }) => ({
  rig: one(miningRigs, {
    fields: [activityLogs.rigId],
    references: [miningRigs.id],
  }),
}));

// Zod schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMiningRigSchema = createInsertSchema(miningRigs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMiningPoolSchema = createInsertSchema(miningPools).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  timestamp: true,
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  timestamp: true,
});

export const insertTeraTransactionSchema = createInsertSchema(teraTransactions).omit({
  id: true,
  timestamp: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type MiningRig = typeof miningRigs.$inferSelect;
export type InsertMiningRig = z.infer<typeof insertMiningRigSchema>;
export type MiningPool = typeof miningPools.$inferSelect;
export type InsertMiningPool = z.infer<typeof insertMiningPoolSchema>;
export type AIEntity = typeof aiEntities.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type TeraTransaction = typeof teraTransactions.$inferSelect;
export type InsertTeraTransaction = z.infer<typeof insertTeraTransactionSchema>;
export type SecurityEvent = typeof securityEvents.$inferSelect;

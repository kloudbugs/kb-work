import {
  users,
  miningRigs,
  miningPools,
  aiEntities,
  chatMessages,
  activityLogs,
  teraTransactions,
  securityEvents,
  type User,
  type UpsertUser,
  type MiningRig,
  type InsertMiningRig,
  type MiningPool,
  type InsertMiningPool,
  type AIEntity,
  type ChatMessage,
  type InsertChatMessage,
  type ActivityLog,
  type InsertActivityLog,
  type TeraTransaction,
  type InsertTeraTransaction,
  type SecurityEvent,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Mining rig operations
  getMiningRigs(userId: string): Promise<MiningRig[]>;
  createMiningRig(rig: InsertMiningRig): Promise<MiningRig>;
  updateMiningRig(id: string, updates: Partial<MiningRig>): Promise<MiningRig | undefined>;
  deleteMiningRig(id: string): Promise<boolean>;
  
  // Mining pool operations
  getMiningPools(): Promise<MiningPool[]>;
  createMiningPool(pool: InsertMiningPool): Promise<MiningPool>;
  updateMiningPool(id: string, updates: Partial<MiningPool>): Promise<MiningPool | undefined>;
  
  // AI entity operations
  getAIEntities(): Promise<AIEntity[]>;
  createAIEntity(entity: Omit<AIEntity, 'id' | 'lastActivity' | 'createdAt' | 'updatedAt'>): Promise<AIEntity>;
  updateAIEntity(id: string, updates: Partial<AIEntity>): Promise<AIEntity | undefined>;
  
  // Chat operations
  getChatMessages(limit?: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // Activity log operations
  getActivityLogs(rigId?: string, limit?: number): Promise<ActivityLog[]>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  
  // TERA token operations
  getTeraTransactions(userId: string, limit?: number): Promise<TeraTransaction[]>;
  createTeraTransaction(transaction: InsertTeraTransaction): Promise<TeraTransaction>;
  updateUserTeraTokens(userId: string, amount: number): Promise<User | undefined>;
  
  // Security operations
  getSecurityEvents(limit?: number): Promise<SecurityEvent[]>;
  createSecurityEvent(event: Omit<SecurityEvent, 'id' | 'timestamp'>): Promise<SecurityEvent>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Mining rig operations
  async getMiningRigs(userId: string): Promise<MiningRig[]> {
    return await db
      .select()
      .from(miningRigs)
      .where(eq(miningRigs.userId, userId))
      .orderBy(desc(miningRigs.createdAt));
  }

  async createMiningRig(rig: InsertMiningRig): Promise<MiningRig> {
    const [newRig] = await db.insert(miningRigs).values(rig).returning();
    return newRig;
  }

  async updateMiningRig(id: string, updates: Partial<MiningRig>): Promise<MiningRig | undefined> {
    const [updatedRig] = await db
      .update(miningRigs)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(miningRigs.id, id))
      .returning();
    return updatedRig;
  }

  async deleteMiningRig(id: string): Promise<boolean> {
    const result = await db.delete(miningRigs).where(eq(miningRigs.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Mining pool operations
  async getMiningPools(): Promise<MiningPool[]> {
    return await db.select().from(miningPools).orderBy(desc(miningPools.createdAt));
  }

  async createMiningPool(pool: InsertMiningPool): Promise<MiningPool> {
    const [newPool] = await db.insert(miningPools).values(pool).returning();
    return newPool;
  }

  async updateMiningPool(id: string, updates: Partial<MiningPool>): Promise<MiningPool | undefined> {
    const [updatedPool] = await db
      .update(miningPools)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(miningPools.id, id))
      .returning();
    return updatedPool;
  }

  // AI entity operations
  async getAIEntities(): Promise<AIEntity[]> {
    return await db.select().from(aiEntities).orderBy(desc(aiEntities.lastActivity));
  }

  async createAIEntity(entity: Omit<AIEntity, 'id' | 'lastActivity' | 'createdAt' | 'updatedAt'>): Promise<AIEntity> {
    const [newEntity] = await db
      .insert(aiEntities)
      .values({
        ...entity,
        lastActivity: new Date(),
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return newEntity;
  }

  async updateAIEntity(id: string, updates: Partial<AIEntity>): Promise<AIEntity | undefined> {
    const [updatedEntity] = await db
      .update(aiEntities)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(aiEntities.id, id))
      .returning();
    return updatedEntity;
  }

  // Chat operations
  async getChatMessages(limit: number = 50): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .orderBy(desc(chatMessages.timestamp))
      .limit(limit);
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db.insert(chatMessages).values(message).returning();
    return newMessage;
  }

  // Activity log operations
  async getActivityLogs(rigId?: string, limit: number = 100): Promise<ActivityLog[]> {
    const query = db.select().from(activityLogs);
    
    if (rigId) {
      return await query
        .where(eq(activityLogs.rigId, rigId))
        .orderBy(desc(activityLogs.timestamp))
        .limit(limit);
    }
    
    return await query
      .orderBy(desc(activityLogs.timestamp))
      .limit(limit);
  }

  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const [newLog] = await db.insert(activityLogs).values(log).returning();
    return newLog;
  }

  // TERA token operations
  async getTeraTransactions(userId: string, limit: number = 50): Promise<TeraTransaction[]> {
    return await db
      .select()
      .from(teraTransactions)
      .where(eq(teraTransactions.userId, userId))
      .orderBy(desc(teraTransactions.timestamp))
      .limit(limit);
  }

  async createTeraTransaction(transaction: InsertTeraTransaction): Promise<TeraTransaction> {
    const [newTransaction] = await db.insert(teraTransactions).values(transaction).returning();
    return newTransaction;
  }

  async updateUserTeraTokens(userId: string, amount: number): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({ 
        teraTokens: amount,
        updatedAt: new Date() 
      })
      .where(eq(users.id, userId))
      .returning();
    return updatedUser;
  }

  // Security operations
  async getSecurityEvents(limit: number = 100): Promise<SecurityEvent[]> {
    return await db
      .select()
      .from(securityEvents)
      .orderBy(desc(securityEvents.timestamp))
      .limit(limit);
  }

  async createSecurityEvent(event: Omit<SecurityEvent, 'id' | 'timestamp'>): Promise<SecurityEvent> {
    const [newEvent] = await db.insert(securityEvents).values(event).returning();
    return newEvent;
  }
}

export const storage = new DatabaseStorage();

import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { 
  insertMiningRigSchema, 
  insertMiningPoolSchema, 
  insertChatMessageSchema,
  insertActivityLogSchema,
  insertTeraTransactionSchema
} from "@shared/schema";
import { z } from "zod";

interface WebSocketClient extends WebSocket {
  userId?: string;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const connectedClients = new Set<WebSocketClient>();

  wss.on('connection', (ws: WebSocketClient) => {
    connectedClients.add(ws);
    
    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        if (message.type === 'auth' && message.userId) {
          ws.userId = message.userId;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      connectedClients.delete(ws);
    });
  });

  // Broadcast function for real-time updates
  const broadcast = (data: any, userId?: string) => {
    const message = JSON.stringify(data);
    connectedClients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        if (!userId || client.userId === userId) {
          client.send(message);
        }
      }
    });
  };

  // Mining Rigs API
  app.get('/api/mining-rigs', async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ message: 'User ID required' });
      }
      
      const rigs = await storage.getMiningRigs(userId);
      res.json(rigs);
    } catch (error) {
      console.error('Error fetching mining rigs:', error);
      res.status(500).json({ message: 'Failed to fetch mining rigs' });
    }
  });

  app.post('/api/mining-rigs', async (req, res) => {
    try {
      const rigData = insertMiningRigSchema.parse(req.body);
      const newRig = await storage.createMiningRig(rigData);
      
      // Broadcast the new rig to connected clients
      broadcast({ type: 'rig_created', rig: newRig }, rigData.userId);
      
      // Log the creation
      await storage.createActivityLog({
        rigId: newRig.id,
        logType: 'info',
        message: `Mining rig ${newRig.name} created successfully`,
        metadata: { action: 'create', rigName: newRig.name }
      });
      
      res.status(201).json(newRig);
    } catch (error) {
      console.error('Error creating mining rig:', error);
      res.status(500).json({ message: 'Failed to create mining rig' });
    }
  });

  app.patch('/api/mining-rigs/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const updatedRig = await storage.updateMiningRig(id, updates);
      if (!updatedRig) {
        return res.status(404).json({ message: 'Mining rig not found' });
      }
      
      // Broadcast the update
      broadcast({ type: 'rig_updated', rig: updatedRig }, updatedRig.userId);
      
      // Log the update
      await storage.createActivityLog({
        rigId: updatedRig.id,
        logType: 'info',
        message: `Mining rig ${updatedRig.name} updated: ${Object.keys(updates).join(', ')}`,
        metadata: { action: 'update', changes: updates }
      });
      
      res.json(updatedRig);
    } catch (error) {
      console.error('Error updating mining rig:', error);
      res.status(500).json({ message: 'Failed to update mining rig' });
    }
  });

  app.delete('/api/mining-rigs/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteMiningRig(id);
      
      if (!success) {
        return res.status(404).json({ message: 'Mining rig not found' });
      }
      
      // Broadcast the deletion
      broadcast({ type: 'rig_deleted', rigId: id });
      
      res.json({ message: 'Mining rig deleted successfully' });
    } catch (error) {
      console.error('Error deleting mining rig:', error);
      res.status(500).json({ message: 'Failed to delete mining rig' });
    }
  });

  // Mining Pools API
  app.get('/api/mining-pools', async (req, res) => {
    try {
      const pools = await storage.getMiningPools();
      res.json(pools);
    } catch (error) {
      console.error('Error fetching mining pools:', error);
      res.status(500).json({ message: 'Failed to fetch mining pools' });
    }
  });

  app.post('/api/mining-pools', async (req, res) => {
    try {
      const poolData = insertMiningPoolSchema.parse(req.body);
      const newPool = await storage.createMiningPool(poolData);
      
      // Broadcast the new pool
      broadcast({ type: 'pool_created', pool: newPool });
      
      res.status(201).json(newPool);
    } catch (error) {
      console.error('Error creating mining pool:', error);
      res.status(500).json({ message: 'Failed to create mining pool' });
    }
  });

  app.patch('/api/mining-pools/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const updatedPool = await storage.updateMiningPool(id, updates);
      if (!updatedPool) {
        return res.status(404).json({ message: 'Mining pool not found' });
      }
      
      // Broadcast the update
      broadcast({ type: 'pool_updated', pool: updatedPool });
      
      res.json(updatedPool);
    } catch (error) {
      console.error('Error updating mining pool:', error);
      res.status(500).json({ message: 'Failed to update mining pool' });
    }
  });

  // AI Entities API
  app.get('/api/ai-entities', async (req, res) => {
    try {
      const entities = await storage.getAIEntities();
      res.json(entities);
    } catch (error) {
      console.error('Error fetching AI entities:', error);
      res.status(500).json({ message: 'Failed to fetch AI entities' });
    }
  });

  app.patch('/api/ai-entities/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const updatedEntity = await storage.updateAIEntity(id, updates);
      if (!updatedEntity) {
        return res.status(404).json({ message: 'AI entity not found' });
      }
      
      // Broadcast the update
      broadcast({ type: 'ai_entity_updated', entity: updatedEntity });
      
      res.json(updatedEntity);
    } catch (error) {
      console.error('Error updating AI entity:', error);
      res.status(500).json({ message: 'Failed to update AI entity' });
    }
  });

  // Chat API
  app.get('/api/chat-messages', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const messages = await storage.getChatMessages(limit);
      res.json(messages.reverse()); // Return in chronological order
    } catch (error) {
      console.error('Error fetching chat messages:', error);
      res.status(500).json({ message: 'Failed to fetch chat messages' });
    }
  });

  app.post('/api/chat-messages', async (req, res) => {
    try {
      const messageData = insertChatMessageSchema.parse(req.body);
      const newMessage = await storage.createChatMessage(messageData);
      
      // Broadcast the new message
      broadcast({ type: 'chat_message', message: newMessage });
      
      res.status(201).json(newMessage);
    } catch (error) {
      console.error('Error creating chat message:', error);
      res.status(500).json({ message: 'Failed to create chat message' });
    }
  });

  // Activity Logs API
  app.get('/api/activity-logs', async (req, res) => {
    try {
      const rigId = req.query.rigId as string;
      const limit = parseInt(req.query.limit as string) || 100;
      const logs = await storage.getActivityLogs(rigId, limit);
      res.json(logs.reverse()); // Return in chronological order
    } catch (error) {
      console.error('Error fetching activity logs:', error);
      res.status(500).json({ message: 'Failed to fetch activity logs' });
    }
  });

  app.post('/api/activity-logs', async (req, res) => {
    try {
      const logData = insertActivityLogSchema.parse(req.body);
      const newLog = await storage.createActivityLog(logData);
      
      // Broadcast the new log
      broadcast({ type: 'activity_log', log: newLog });
      
      res.status(201).json(newLog);
    } catch (error) {
      console.error('Error creating activity log:', error);
      res.status(500).json({ message: 'Failed to create activity log' });
    }
  });

  // TERA Tokens API
  app.get('/api/tera-transactions/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      const limit = parseInt(req.query.limit as string) || 50;
      const transactions = await storage.getTeraTransactions(userId, limit);
      res.json(transactions.reverse()); // Return in chronological order
    } catch (error) {
      console.error('Error fetching TERA transactions:', error);
      res.status(500).json({ message: 'Failed to fetch TERA transactions' });
    }
  });

  app.post('/api/tera-transactions', async (req, res) => {
    try {
      const transactionData = insertTeraTransactionSchema.parse(req.body);
      const newTransaction = await storage.createTeraTransaction(transactionData);
      
      // Update user's TERA token balance
      const user = await storage.getUser(transactionData.userId);
      if (user) {
        const newBalance = user.teraTokens + transactionData.amount;
        await storage.updateUserTeraTokens(transactionData.userId, newBalance);
        
        // Broadcast the transaction and balance update
        broadcast({ 
          type: 'tera_transaction', 
          transaction: newTransaction,
          newBalance
        }, transactionData.userId);
      }
      
      res.status(201).json(newTransaction);
    } catch (error) {
      console.error('Error creating TERA transaction:', error);
      res.status(500).json({ message: 'Failed to create TERA transaction' });
    }
  });

  // Security Events API
  app.get('/api/security-events', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const events = await storage.getSecurityEvents(limit);
      res.json(events);
    } catch (error) {
      console.error('Error fetching security events:', error);
      res.status(500).json({ message: 'Failed to fetch security events' });
    }
  });

  // Dashboard Stats API
  app.get('/api/dashboard/stats/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Get user's mining rigs
      const rigs = await storage.getMiningRigs(userId);
      const activeRigs = rigs.filter(rig => rig.status === 'mining');
      
      // Calculate total hash rate
      const totalHashRate = activeRigs.reduce((sum, rig) => sum + rig.hashRate, 0);
      
      // Calculate total power consumption
      const totalPower = activeRigs.reduce((sum, rig) => sum + rig.power, 0);
      
      // Get user's TERA token balance
      const user = await storage.getUser(userId);
      const teraTokens = user?.teraTokens || 0;
      
      // Calculate efficiency (average of all active rigs)
      const efficiency = activeRigs.length > 0
        ? activeRigs.reduce((sum, rig) => sum + (rig.efficiency || 0), 0) / activeRigs.length
        : 0;
      
      const stats = {
        totalHashRate,
        activeRigs: activeRigs.length,
        totalRigs: rigs.length,
        totalPower,
        teraTokens,
        efficiency: Math.round(efficiency),
        uptimePercentage: 99.7 // This would be calculated from actual uptime data
      };
      
      res.json(stats);
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      res.status(500).json({ message: 'Failed to fetch dashboard stats' });
    }
  });

  // Ghost Core platform integration endpoints
  app.get('/api/ghost-core/platforms', async (req, res) => {
    try {
      // Return empty array for now - platform data will be added when user provides repository
      const platforms: any[] = [];
      res.json(platforms);
    } catch (error) {
      console.error('Error fetching platforms:', error);
      res.status(500).json({ message: 'Failed to fetch platforms' });
    }
  });

  app.get('/api/ghost-core/status', async (req, res) => {
    try {
      const status = {
        ghostCoreActive: true,
        connectedPlatforms: 0,
        lastSync: new Date(),
        systemLoad: 45,
        communicationProtocol: 'ghost_protocol'
      };
      res.json(status);
    } catch (error) {
      console.error('Error fetching ghost core status:', error);
      res.status(500).json({ message: 'Failed to fetch ghost core status' });
    }
  });

  app.post('/api/ghost-core/integrate-platform', async (req, res) => {
    try {
      const { repository, apiEndpoints } = req.body;
      
      // Create activity log for platform integration
      await storage.createActivityLog({
        logType: 'info',
        message: `Platform integration initiated: ${repository}`,
        metadata: { repository, apiEndpoints }
      });

      // In a real implementation, you would:
      // 1. Clone the repository
      // 2. Analyze the codebase
      // 3. Set up API connections
      // 4. Create integration mappings
      
      const integration = {
        id: crypto.randomUUID(),
        name: repository.split('/').pop() || 'Unknown Platform',
        repository,
        apiEndpoints,
        status: 'pending',
        timestamp: new Date()
      };

      res.json({ success: true, integration });
    } catch (error) {
      console.error('Error integrating platform:', error);
      res.status(500).json({ message: 'Failed to integrate platform' });
    }
  });

  app.post('/api/ghost-core/execute', async (req, res) => {
    try {
      const { command, platform, context } = req.body;
      let result = '';

      // Process Ghost Core commands
      if (command.toLowerCase().includes('sync platforms')) {
        result = 'Platform synchronization initiated. All connected platforms are being updated with latest configurations.';
        
        await storage.createActivityLog({
          logType: 'info',
          message: 'Ghost Core: Platform sync command executed',
          metadata: { command, context }
        });
        
      } else if (command.toLowerCase().includes('status report')) {
        const aiEntities = await storage.getAIEntities();
        const activeCount = aiEntities.filter(ai => ai.status === 'active').length;
        
        result = `Ghost Core Status Report:
- Active AI Entities: ${activeCount}/${aiEntities.length}
- Platform Integrations: 0 connected
- System Load: 45%
- Communication Protocol: Active
- Last Platform Sync: ${new Date().toLocaleString()}`;

      } else if (command.toLowerCase().includes('optimize all')) {
        result = 'System-wide optimization initiated. AI entities are coordinating to improve performance across all platforms.';
        
        // Update AI entities to active status
        const aiEntities = await storage.getAIEntities();
        for (const ai of aiEntities) {
          await storage.updateAIEntity(ai.id, { status: 'active' });
        }
        
      } else if (command.toLowerCase().includes('security scan')) {
        await storage.createSecurityEvent({
          eventType: 'ghost_core_scan',
          severity: 'medium',
          description: 'Ghost Core initiated comprehensive security scan',
          userId: null,
          sourceIp: null,
          resolved: false
        });
        
        result = 'Ghost Core security scan initiated. Analyzing all connected platforms and AI entities for potential threats.';
        
      } else {
        // Generic command processing
        result = `Ghost Core processed command: "${command}". Command executed through ${context?.isGhostMode ? 'Ghost Mode' : 'Standard Mode'} protocol.`;
      }

      res.json({ success: true, result });
    } catch (error) {
      console.error('Error executing Ghost Core command:', error);
      res.status(500).json({ message: 'Failed to execute command' });
    }
  });

  // AI Command Processing API
  app.post('/api/ai-command', async (req, res) => {
    try {
      const { command, userId } = req.body;
      
      // Simulate AI command processing
      let response = "Command processed successfully.";
      
      // Process different types of commands
      if (command.toLowerCase().includes('optimize')) {
        // Simulate optimization
        const rigs = await storage.getMiningRigs(userId);
        for (const rig of rigs.filter(r => r.status === 'mining')) {
          const newEfficiency = Math.min(100, (rig.efficiency || 80) + Math.random() * 5);
          await storage.updateMiningRig(rig.id, { efficiency: newEfficiency });
        }
        response = "Mining optimization completed. Efficiency improved across all active rigs.";
      } else if (command.toLowerCase().includes('security')) {
        // Create security event
        await storage.createSecurityEvent({
          eventType: 'security_scan',
          severity: 'low',
          description: 'Automated security scan initiated by AI command',
          userId,
          sourceIp: null,
          resolved: false
        });
        response = "Security scan initiated. All systems nominal.";
      } else if (command.toLowerCase().includes('temperature') || command.toLowerCase().includes('cooling')) {
        // Simulate temperature management
        const rigs = await storage.getMiningRigs(userId);
        for (const rig of rigs) {
          const newTemp = Math.max(45, rig.temperature - Math.random() * 10);
          await storage.updateMiningRig(rig.id, { temperature: newTemp });
        }
        response = "Temperature optimization applied. Cooling systems activated.";
      }
      
      // Create AI chat response
      await storage.createChatMessage({
        senderId: 'ghost-alpha',
        senderType: 'ai',
        message: response,
        aiPersonality: 'ghost_alpha'
      });
      
      // Broadcast the AI response
      broadcast({ 
        type: 'ai_response', 
        message: {
          senderId: 'ghost-alpha',
          senderType: 'ai',
          message: response,
          aiPersonality: 'ghost_alpha',
          timestamp: new Date()
        }
      });
      
      res.json({ success: true, response });
    } catch (error) {
      console.error('Error processing AI command:', error);
      res.status(500).json({ message: 'Failed to process AI command' });
    }
  });

  return httpServer;
}
